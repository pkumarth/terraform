terraform init  -var-file=prod/terraform.tfvars
terraform plan -var-file=prod/terraform.tfvars