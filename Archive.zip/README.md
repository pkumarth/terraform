# terraform
https://github.com/neamulkabiremon/terraform-aws-ecs-fargate-infra/blob/main/modules/vpc/main.tf