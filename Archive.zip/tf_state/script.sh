aws s3api create-bucket \
  --bucket my-ecs-terraform-state \
  --region us-east-1

  aws s3api put-bucket-versioning \
  --bucket my-ecs-terraform-state \
  --versioning-configuration Status=Enabled

  aws dynamodb create-table \
  --table-name terraform-locks \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST